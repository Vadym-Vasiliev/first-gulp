import * as flsFunctions from "./modules/functions.js";

flsFunctions.isWebp();
